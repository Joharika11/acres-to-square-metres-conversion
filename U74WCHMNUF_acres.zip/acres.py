acres = float(input())

acre_to_squaremeters= 4046.86

square_meters = acres * acre_to_squaremeters
print(str(acres )+" acres = " + str(square_meters)+" square meters")